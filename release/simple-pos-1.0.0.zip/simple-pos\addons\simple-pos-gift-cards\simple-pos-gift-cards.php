<?php
/**
 * Plugin Name: Simple POS — Gift Cards
 * Description: Sell and redeem gift card codes. Requires the free Simple POS plugin.
 * Version:     1.0.0
 * Author:      Simple POS
 * Text Domain: simple-pos
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SIMPLE_POS_SGC_VERSION', '1.0.0' );

add_action( 'simple_pos_init', 'simple_pos_sgc_boot' );

function simple_pos_sgc_boot() {
	if ( ! class_exists( 'Simple_POS_Addons' ) ) {
		add_action(
			'admin_notices',
			function () {
				echo '<div class="notice notice-error"><p>';
				esc_html_e( 'Simple POS — Gift Cards requires the free Simple POS plugin.', 'simple-pos' );
				echo '</p></div>';
			}
		);
		return;
	}

	require_once __DIR__ . '/includes/class-gift-cards.php';

	add_filter(
		'simple_pos_registered_addons',
		function ( $addons ) {
			$addons[] = array(
				'slug'        => 'gift-cards',
				'name'        => __( 'Gift Cards', 'simple-pos' ),
				'version'     => SIMPLE_POS_SGC_VERSION,
				'description' => __( 'Sell, top up and redeem gift card codes at checkout.', 'simple-pos' ),
			);
			return $addons;
		}
	);

	if ( ! Simple_POS_Addons::is_enabled( 'simple-pos-gift-cards' ) ) {
		return;
	}

	Simple_POS_Sgc_Gift_Cards::ensure_schema();

	add_filter(
		'simple_pos_cart_data',
		function ( $cart_data ) {
			return Simple_POS_Sgc_Gift_Cards::apply_gift_card( $cart_data );
		}
	);

	// Consume the gift card balance once the sale is stored.
	add_action(
		'simple_pos_sale_created',
		function ( $sale_id, $calc, $line_items, $cart_data ) {
			// Idempotency: boots must tolerate running twice (e.g. the
			// bootstrap file loading via two paths); a sale redeems once.
			static $redeemed = array();
			if ( isset( $redeemed[ (int) $sale_id ] ) ) {
				return;
			}
			$code = isset( $cart_data['gift_card_code'] ) ? $cart_data['gift_card_code'] : '';
			$used = isset( $cart_data['gift_card_applied'] ) ? (float) $cart_data['gift_card_applied'] : 0;
			if ( '' !== trim( (string) $code ) && $used > 0 ) {
				Simple_POS_Sgc_Gift_Cards::redeem( $code, $used );
				$redeemed[ (int) $sale_id ] = true;
			}
		},
		20,
		4
	);

	add_filter(
		'simple_pos_rest_product_args',
		function ( $args ) {
			return Simple_POS_Sgc_Gift_Cards::register_gift_card_product_arg( $args );
		}
	);

	add_action(
		'init',
		function () {
			register_rest_route(
				'simple-pos/v1',
				'/giftcards/lookup',
				array(
					'methods'             => 'GET',
					'callback'            => array( 'Simple_POS_Sgc_Gift_Cards', 'rest_lookup' ),
					'permission_callback' => function () {
						return current_user_can( 'operate_pos' );
					},
				)
			);
		}
	);

	add_action(
		'admin_menu',
		function () {
			add_submenu_page(
				'simple-pos-terminal',
				__( 'Gift Cards', 'simple-pos' ),
				__( 'Gift Cards', 'simple-pos' ),
				'manage_pos_products',
				'simple-pos-gift-cards',
				'simple_pos_sgc_render_page'
			);
		}
	);

	add_action( 'admin_post_simple_pos_giftcard_save', 'simple_pos_sgc_handle_save' );
	add_action( 'admin_post_simple_pos_giftcard_topup', 'simple_pos_sgc_handle_topup' );
}

function simple_pos_sgc_render_page() {
	if ( ! current_user_can( 'manage_pos_products' ) ) {
		wp_die( esc_html__( 'You are not allowed to manage gift cards.', 'simple-pos' ) );
	}
	include __DIR__ . '/admin/views/gift-cards.php';
}

function simple_pos_sgc_handle_save() {
	if ( ! current_user_can( 'manage_pos_products' ) ) {
		wp_die( esc_html__( 'You are not allowed to manage gift cards.', 'simple-pos' ) );
	}
	check_admin_referer( 'simple_pos_giftcard_save' );

	$code   = isset( $_POST['code'] ) ? sanitize_text_field( wp_unslash( $_POST['code'] ) ) : '';
	$amount = isset( $_POST['amount'] ) ? (float) $_POST['amount'] : 0;

	if ( '' === $code || $amount <= 0 ) {
		wp_safe_redirect( add_query_arg( 'sgc_msg', 'invalid', admin_url( 'admin.php?page=simple-pos-gift-cards' ) ) );
		exit;
	}

	Simple_POS_Sgc_Gift_Cards::create_card( $code, $amount );

	wp_safe_redirect( add_query_arg( 'sgc_msg', 'created', admin_url( 'admin.php?page=simple-pos-gift-cards' ) ) );
	exit;
}

function simple_pos_sgc_handle_topup() {
	if ( ! current_user_can( 'manage_pos_products' ) ) {
		wp_die( esc_html__( 'You are not allowed to manage gift cards.', 'simple-pos' ) );
	}
	check_admin_referer( 'simple_pos_giftcard_topup' );

	$id     = isset( $_POST['card_id'] ) ? (int) $_POST['card_id'] : 0;
	$amount = isset( $_POST['amount'] ) ? (float) $_POST['amount'] : 0;

	if ( $id > 0 && $amount > 0 ) {
		Simple_POS_Sgc_Gift_Cards::top_up( $id, $amount );
	}

	wp_safe_redirect( add_query_arg( 'sgc_msg', 'topup', admin_url( 'admin.php?page=simple-pos-gift-cards' ) ) );
	exit;
}