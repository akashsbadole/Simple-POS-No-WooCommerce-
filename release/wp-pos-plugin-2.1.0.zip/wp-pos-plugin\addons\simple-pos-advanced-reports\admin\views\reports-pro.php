<?php
/**
 * Reports Pro screen.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$date_from = isset( $_GET['date_from'] ) ? sanitize_text_field( wp_unslash( $_GET['date_from'] ) ) : gmdate( 'Y-m-01' );
$date_to   = isset( $_GET['date_to'] ) ? sanitize_text_field( wp_unslash( $_GET['date_to'] ) ) : gmdate( 'Y-m-d' );
$cashier   = isset( $_GET['cashier_id'] ) ? (int) $_GET['cashier_id'] : 0;

$xz       = SPAR_Reports::xz( $date_from, $date_to, $cashier );
$hourly   = SPAR_Reports::hourly( $date_from, $date_to );
$payments = SPAR_Reports::payment_mix( $date_from, $date_to, $cashier );
$products = SPAR_Reports::product_mix( $date_from, $date_to, 20 );
$taxes    = SPAR_Reports::tax_summary( $date_from, $date_to, $cashier );
$cashiers = Simple_POS_Reports::get_sales_by_cashier( $date_from, $date_to );

$max_hour = 0;
foreach ( $hourly as $h ) {
	$max_hour = max( $max_hour, $h['revenue'] );
}

$export_url = function ( $type ) use ( $date_from, $date_to, $cashier ) {
	return wp_nonce_url(
		add_query_arg(
			array(
				'action'     => 'simple_pos_adv_reports_export',
				'type'       => $type,
				'date_from'  => $date_from,
				'date_to'    => $date_to,
				'cashier_id' => $cashier,
			),
			admin_url( 'admin-post.php' )
		),
		'simple_pos_adv_reports_export'
	);
};
?>
<div class="wrap simple-pos-wrap">
	<div class="simple-pos-page-header">
		<h1><?php esc_html_e( 'Reports Pro', 'wp-pos-plugin' ); ?></h1>
	</div>

	<form method="get" class="simple-pos-card simple-pos-filters">
		<input type="hidden" name="page" value="simple-pos-adv-reports" />
		<div class="simple-pos-filter-field">
			<label><?php esc_html_e( 'From', 'wp-pos-plugin' ); ?></label>
			<input type="date" name="date_from" value="<?php echo esc_attr( $date_from ); ?>" />
		</div>
		<div class="simple-pos-filter-field">
			<label><?php esc_html_e( 'To', 'wp-pos-plugin' ); ?></label>
			<input type="date" name="date_to" value="<?php echo esc_attr( $date_to ); ?>" />
		</div>
		<div class="simple-pos-filter-field">
			<label><?php esc_html_e( 'Cashier', 'wp-pos-plugin' ); ?></label>
			<select name="cashier_id">
				<option value="0"><?php esc_html_e( 'All cashiers', 'wp-pos-plugin' ); ?></option>
				<?php foreach ( $cashiers as $c ) : ?>
					<option value="<?php echo esc_attr( $c->cashier_id ); ?>" <?php selected( $cashier, (int) $c->cashier_id ); ?>><?php echo esc_html( $c->cashier_name ); ?></option>
				<?php endforeach; ?>
			</select>
		</div>
		<div class="simple-pos-filter-actions">
			<button class="button button-primary" type="submit"><?php esc_html_e( 'Apply', 'wp-pos-plugin' ); ?></button>
		</div>
	</form>

	<div class="simple-pos-card simple-pos-table-card">
		<h2 class="simple-pos-section-title" style="margin:0;padding:14px 14px 0">
			<?php esc_html_e( 'X / Z summary', 'wp-pos-plugin' ); ?>
			<a class="button" style="float:right" href="<?php echo esc_url( $export_url( 'xz' ) ); ?>"><?php esc_html_e( 'CSV', 'wp-pos-plugin' ); ?></a>
		</h2>
		<table class="wp-list-table widefat striped simple-pos-table" style="margin-top:10px">
			<tbody>
				<tr><td><strong><?php esc_html_e( 'Sales', 'wp-pos-plugin' ); ?></strong></td><td><?php echo esc_html( $xz['sale_count'] ); ?></td><td><strong><?php esc_html_e( 'Items sold', 'wp-pos-plugin' ); ?></strong></td><td><?php echo esc_html( $xz['items_sold'] ); ?></td></tr>
				<tr><td><strong><?php esc_html_e( 'Gross', 'wp-pos-plugin' ); ?></strong></td><td><?php echo esc_html( Simple_POS_DB::format_currency( $xz['gross'] ) ); ?></td><td><strong><?php esc_html_e( 'Discount', 'wp-pos-plugin' ); ?></strong></td><td><?php echo esc_html( Simple_POS_DB::format_currency( $xz['discount'] ) ); ?></td></tr>
				<tr><td><strong><?php esc_html_e( 'Tax', 'wp-pos-plugin' ); ?></strong></td><td><?php echo esc_html( Simple_POS_DB::format_currency( $xz['tax'] ) ); ?></td><td><strong><?php esc_html_e( 'Net', 'wp-pos-plugin' ); ?></strong></td><td><?php echo esc_html( Simple_POS_DB::format_currency( $xz['net'] ) ); ?></td></tr>
				<tr><td><strong><?php esc_html_e( 'Avg basket', 'wp-pos-plugin' ); ?></strong></td><td><?php echo esc_html( Simple_POS_DB::format_currency( $xz['avg_basket'] ) ); ?></td><td><strong><?php esc_html_e( 'Gross profit', 'wp-pos-plugin' ); ?></strong></td><td><?php echo esc_html( Simple_POS_DB::format_currency( $xz['gross_profit'] ) ); ?></td></tr>
			</tbody>
		</table>
	</div>

	<div class="simple-pos-card simple-pos-table-card">
		<h2 class="simple-pos-section-title" style="margin:0;padding:14px 14px 0">
			<?php esc_html_e( 'Hourly sales', 'wp-pos-plugin' ); ?>
			<a class="button" style="float:right" href="<?php echo esc_url( $export_url( 'hourly' ) ); ?>"><?php esc_html_e( 'CSV', 'wp-pos-plugin' ); ?></a>
		</h2>
		<table class="wp-list-table widefat striped simple-pos-table" style="margin-top:10px">
			<thead><tr><th><?php esc_html_e( 'Hour', 'wp-pos-plugin' ); ?></th><th class="num"><?php esc_html_e( 'Sales', 'wp-pos-plugin' ); ?></th><th class="num"><?php esc_html_e( 'Revenue', 'wp-pos-plugin' ); ?></th><th style="width:40%">&nbsp;</th></tr></thead>
			<tbody>
				<?php foreach ( $hourly as $h ) : ?>
					<tr>
						<td><?php echo esc_html( sprintf( '%02d:00', $h['hr'] ) ); ?></td>
						<td class="num"><?php echo esc_html( $h['sale_count'] ); ?></td>
						<td class="num"><?php echo esc_html( Simple_POS_DB::format_currency( $h['revenue'] ) ); ?></td>
						<td><div style="background:#2271b1;height:8px;border-radius:4px;width:<?php echo esc_attr( $max_hour > 0 ? round( $h['revenue'] / $max_hour * 100 ) : 0 ); ?>%"></div></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>

	<div class="simple-pos-card simple-pos-table-card">
		<h2 class="simple-pos-section-title" style="margin:0;padding:14px 14px 0">
			<?php esc_html_e( 'Payment mix', 'wp-pos-plugin' ); ?>
			<a class="button" style="float:right" href="<?php echo esc_url( $export_url( 'payments' ) ); ?>"><?php esc_html_e( 'CSV', 'wp-pos-plugin' ); ?></a>
		</h2>
		<table class="wp-list-table widefat striped simple-pos-table" style="margin-top:10px">
			<thead><tr><th><?php esc_html_e( 'Payment method', 'wp-pos-plugin' ); ?></th><th class="num"><?php esc_html_e( 'Sales', 'wp-pos-plugin' ); ?></th><th class="num"><?php esc_html_e( 'Revenue', 'wp-pos-plugin' ); ?></th></tr></thead>
			<tbody>
				<?php if ( empty( $payments ) ) : ?><tr><td colspan="3" class="simple-pos-empty"><?php esc_html_e( 'No sales in this range.', 'wp-pos-plugin' ); ?></td></tr><?php endif; ?>
				<?php foreach ( $payments as $p ) : ?>
					<tr><td><?php echo esc_html( ucfirst( $p->payment_method ) ); ?></td><td class="num"><?php echo esc_html( $p->sale_count ); ?></td><td class="num"><?php echo esc_html( Simple_POS_DB::format_currency( $p->revenue ) ); ?></td></tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>

	<div class="simple-pos-card simple-pos-table-card">
		<h2 class="simple-pos-section-title" style="margin:0;padding:14px 14px 0">
			<?php esc_html_e( 'Product mix (top 20)', 'wp-pos-plugin' ); ?>
			<a class="button" style="float:right" href="<?php echo esc_url( $export_url( 'products' ) ); ?>"><?php esc_html_e( 'CSV', 'wp-pos-plugin' ); ?></a>
		</h2>
		<table class="wp-list-table widefat striped simple-pos-table" style="margin-top:10px">
			<thead><tr><th><?php esc_html_e( 'Product', 'wp-pos-plugin' ); ?></th><th><?php esc_html_e( 'SKU', 'wp-pos-plugin' ); ?></th><th class="num"><?php esc_html_e( 'Qty', 'wp-pos-plugin' ); ?></th><th class="num"><?php esc_html_e( 'Revenue', 'wp-pos-plugin' ); ?></th><th class="num"><?php esc_html_e( 'Profit', 'wp-pos-plugin' ); ?></th><th class="num"><?php esc_html_e( 'Margin', 'wp-pos-plugin' ); ?></th></tr></thead>
			<tbody>
				<?php if ( empty( $products ) ) : ?><tr><td colspan="6" class="simple-pos-empty"><?php esc_html_e( 'No sales in this range.', 'wp-pos-plugin' ); ?></td></tr><?php endif; ?>
				<?php foreach ( $products as $p ) : ?>
					<tr>
						<td><?php echo esc_html( $p->product_name ); ?></td>
						<td><code><?php echo esc_html( $p->sku ?: '—' ); ?></code></td>
						<td class="num"><?php echo esc_html( $p->qty ); ?></td>
						<td class="num"><?php echo esc_html( Simple_POS_DB::format_currency( $p->revenue ) ); ?></td>
						<td class="num"><?php echo esc_html( Simple_POS_DB::format_currency( $p->profit ) ); ?></td>
						<td class="num"><?php echo esc_html( $p->margin . '%' ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>

	<div class="simple-pos-card simple-pos-table-card">
		<h2 class="simple-pos-section-title" style="margin:0;padding:14px 14px 0">
			<?php esc_html_e( 'Tax summary', 'wp-pos-plugin' ); ?>
			<a class="button" style="float:right" href="<?php echo esc_url( $export_url( 'taxes' ) ); ?>"><?php esc_html_e( 'CSV', 'wp-pos-plugin' ); ?></a>
		</h2>
		<table class="wp-list-table widefat striped simple-pos-table" style="margin-top:10px">
			<thead><tr><th><?php esc_html_e( 'Tax', 'wp-pos-plugin' ); ?></th><th class="num"><?php esc_html_e( 'Rate', 'wp-pos-plugin' ); ?></th><th class="num"><?php esc_html_e( 'Amount', 'wp-pos-plugin' ); ?></th></tr></thead>
			<tbody>
				<?php if ( empty( $taxes ) ) : ?><tr><td colspan="3" class="simple-pos-empty"><?php esc_html_e( 'No tax collected in this range.', 'wp-pos-plugin' ); ?></td></tr><?php endif; ?>
				<?php foreach ( $taxes as $t ) : ?>
					<tr><td><?php echo esc_html( $t['name'] ); ?></td><td class="num"><?php echo esc_html( $t['rate'] . '%' ); ?></td><td class="num"><?php echo esc_html( Simple_POS_DB::format_currency( $t['amount'] ) ); ?></td></tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</div>
